'use strict'
angular.module('batApp').constant('configuration', {
  apihost: 'http://144.76.34.244:3016'
})
